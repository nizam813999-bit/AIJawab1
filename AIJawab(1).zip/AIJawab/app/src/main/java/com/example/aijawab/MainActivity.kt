package com.example.aijawab

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
        }
        val info = TextView(this).apply {
            text = "AI Jawab\n\nMasukkan API key Anthropic kamu (disimpan hanya di HP ini), lalu tekan Mulai. " +
                "Izinkan 'tampil di atas aplikasi lain' dan rekam layar. Untuk latihan soal dan belajar, bukan untuk ujian."
        }
        val key = EditText(this).apply {
            hint = "API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val start = Button(this).apply { text = "Mulai tombol AI" }
        val stop = Button(this).apply { text = "Hentikan" }
        root.addView(info); root.addView(key); root.addView(start); root.addView(stop)
        setContentView(root)

        start.setOnClickListener {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Izinkan lalu tekan Mulai lagi", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        }
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
