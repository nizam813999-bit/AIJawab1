package com.example.aijawab

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.view.*
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var button: View? = null
    private var panel: View? = null
    private var w = 0
    private var h = 0
    private val dp get() = resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = resources.displayMetrics
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        showButton()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ai", "AI Jawab", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ai")
            .setContentTitle("AI Jawab aktif")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun showButton() {
        val b = TextView(this).apply {
            text = "AI"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            textSize = 16f; setTypeface(null, Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF5B4BDB.toInt()) }
        }
        val lp = WindowManager.LayoutParams(
            (56 * dp).toInt(), (56 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (200 * dp).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(b, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) ask(); true }
                else -> false
            }
        }
        wm.addView(b, lp); button = b
    }

    private fun show(msg: String) {
        panel?.let { runCatching { wm.removeView(it) } }
        val tv = TextView(this).apply {
            text = msg; setTextColor(Color.WHITE); textSize = 15f
            setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (24 * dp).toInt())
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(0xEE101020.toInt()); addView(tv)
            setOnClickListener { runCatching { wm.removeView(this) }; panel = null }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, (320 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        wm.addView(sv, lp); panel = sv
    }

    private fun ask() {
        val img = reader?.acquireLatestImage()
        if (img == null) { show("Layar belum terbaca. Geser layar sedikit lalu ketuk tombol AI lagi."); return }
        val plane = img.planes[0]
        val rowPad = plane.rowStride - plane.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        img.close()
        val shot = Bitmap.createBitmap(full, 0, 0, w, h)
        val out = ByteArrayOutputStream()
        shot.compress(Bitmap.CompressFormat.JPEG, 80, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        show("AI sedang berpikir…")
        Thread { val r = callClaude(b64); handler.post { show(r) } }.start()
    }

    private fun callClaude(b64: String): String {
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text",
                "Ada soal latihan di layar ini. Tulis jawaban yang benar, lalu penjelasan singkat dalam bahasa Indonesia."))
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 800)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        return try {
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 20000; c.readTimeout = 60000
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) "Error $code: $txt"
            else JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Gagal: ${e.message}" }
    }

    override fun onDestroy() {
        button?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
